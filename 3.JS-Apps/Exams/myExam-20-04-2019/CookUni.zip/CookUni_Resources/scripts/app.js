$(() => {
  const app = Sammy('#rooter', function () {
    this.use('Handlebars', 'hbs');

    let isLogged = Boolean(sessionStorage.getItem('authtoken'));
    const categoryUrls = {
      "Vegetables and legumes/beans": "https://cdn.pixabay.com/photo/2017/10/09/19/29/eat-2834549__340.jpg",
      "Fruits": "https://cdn.pixabay.com/photo/2017/06/02/18/24/fruit-2367029__340.jpg",
      "Grain Food": "https://cdn.pixabay.com/photo/2014/12/11/02/55/corn-syrup-563796__340.jpg",
      "Milk, cheese, eggs and alternatives": "https://image.shutterstock.com/image-photo/assorted-dairy-products-milk-yogurt-260nw-530162824.jpg",
      "Lean meats and poultry, fish and alternatives": "https://t3.ftcdn.net/jpg/01/18/84/52/240_F_118845283_n9uWnb81tg8cG7Rf9y3McWT1DT1ZKTDx.jpg",
    };


    // ROUTES:
    // home - get
    this.get('#/home', function (ctx) {
      // check if is logged
      if (Boolean(sessionStorage.getItem('authtoken'))) {
        // get all recipes from kinvey
        requester.get('appdata', 'recipes', 'kinvey')
          .then(function (recipesArr) {
            recipesArr.map(function (recipe) {
              recipe.ingredients = recipe.ingredients
                .split(/[^a-zA-Z]+/)
                .filter(el => el.length > 0);
              return recipe;
            });

            const hasRecipes = (recipesArr.length > 0);
            // display view
            ctx.loadPartials({
              header: '../templates/common/header.hbs',
              footer: '../templates/common/footer.hbs',
              mealPartial: '../templates/mealPartials/mealPartial.hbs',
            }).then(function () {
              this.partial('../templates/home.hbs', {
                isLogged: Boolean(sessionStorage.getItem('authtoken')),
                names: sessionStorage.getItem('names'),
                hasRecipes,
                recipes: recipesArr,
              });
            });
          })
          .catch(err => auth.showError(err.responseJSON.description));
      } else {
        ctx.loadPartials({
          header: '../templates/common/header.hbs',
          footer: '../templates/common/footer.hbs',
        }).then(function () {
          this.partial('../templates/home.hbs', {
            isLogged: Boolean(sessionStorage.getItem('authtoken')),
            names: sessionStorage.getItem('names'),
          });
        });
      }

    });


    // register - get
    this.get('#/register', function (ctx) {
      ctx.loadPartials({
        header: '../templates/common/header.hbs',
        footer: '../templates/common/footer.hbs',
      }).then(function () {
        this.partial('../templates/user/register.hbs', {
          isLogged: Boolean(sessionStorage.getItem('authtoken')),
          names: sessionStorage.getItem('names'),
        });
      });
    });


    // register - post
    this.post('#/register', function (ctx) {
      let { firstName, lastName, username, password, repeatPassword } = ctx.params;
      // inputs check
      if (firstName.length < 2 || lastName.length < 2) {
        auth.showError('The first and last name should be at least 2 characters long');
        return;
      }

      if (username.length < 3) {
        auth.showError('The username should be at least 3 characters long');
        return;
      }

      if (password.length < 6) {
        auth.showError('The password should be at least 6 characters long');
        return;
      }

      if (password !== repeatPassword) {
        auth.showError('The repeat password should be equal to the password');
        return;
      }
      // end of checks

      // const userData = { firstName, lastName, username, password };
      //send register data to kinvey
      auth.register(username, password, firstName, lastName)
        .then(function (userInfo) {
          auth.saveSession(userInfo);
          auth.showInfo('User registration successful.');
          setTimeout(function () {
            ctx.redirect('#/home');
          }, 1000);
        })
        .catch(err => auth.showError(err.responseJSON.description));
    });


    // login - get
    this.get('#/login', function (ctx) {
      ctx.loadPartials({
        header: '../templates/common/header.hbs',
        footer: '../templates/common/footer.hbs',
      }).then(function () {
        this.partial('../templates/user/login.hbs', {
          isLogged: Boolean(sessionStorage.getItem('authtoken')),
          names: sessionStorage.getItem('names'),
        });
      });
    });


    // login - post
    this.post('#/login', function (ctx) {
      const { username, password } = ctx.params;
      // send login data
      auth.login(username, password)
        .then(function (userInfo) {
          auth.showInfo('Login successful.');
          auth.saveSession(userInfo);
          setTimeout(function () {
            ctx.redirect('#/home');
          }, 1000);
        })
        .catch(err => auth.showError(err.responseJSON.description));
    });


    // logout - get
    this.get('#/logout', function (ctx) {
      auth.logout()
        .then(function () {
          auth.showInfo('Logout successful.');
          sessionStorage.clear();
          setTimeout(function () {
            ctx.redirect('#/home');
          }, 1000);
        })
        .catch(err => auth.showError(err.responseJSON.description));
    });


    // share recipe - get
    this.get('#/shareRecipe', function (ctx) {
      ctx.loadPartials({
        header: '../templates/common/header.hbs',
        footer: '../templates/common/footer.hbs',
      }).then(function () {
        this.partial('../templates/recipes/shareRecipe.hbs', {
          isLogged: Boolean(sessionStorage.getItem('authtoken')),
          names: sessionStorage.getItem('names'),
        });
      });
    });


    // share recipe - post
    this.post('#/shareRecipe', function (ctx) {
      const { meal, ingredients, prepMethod, description, foodImageURL, category } = ctx.params;
      // input checks
      if (meal.length < 4) {
        auth.showError('meal should be at least 4 characters long');
        return;
      }

      if (ingredients.split(/[^a-zA-Z]+/).length < 2) {
        auth.showError('ingredients should at least 2');
        return;
      }

      if (prepMethod.length < 10 || description.length < 10) {
        auth.showError('preparation method and description should be at least 10 characters long each.');
        return;
      }

      if (!foodImageURL.startsWith('http://') && !foodImageURL.startsWith('https://')) {
        auth.showError('foodImageURL ("string") should start with "http://" or "https://"');
        return;
      }

      if (category === 'Select category...') {
        auth.showError('please select a category');
        return;
      }
      // end of checks

      const categoryImageURL = categoryUrls[category];
      const recipe = {
        meal,
        ingredients,
        prepMethod,
        description,
        foodImageURL,
        category,
        categoryImageURL,
        likesCounter: 0
      };

      // post recipe to kinvey
      requester.post('appdata', 'recipes', 'kinvey', JSON.parse(JSON.stringify(recipe)))
        .then(function () {
          auth.showInfo('Recipe shared successfully!');
          setTimeout(function () {
            ctx.redirect('#/home');
          }, 1000);
        })
        .catch(err => auth.showError(err.responseJSON.description));


    });


    // details - get
    this.get('#/details/:recipeId', function (ctx) {
      const recipeId = ctx.params.recipeId;
      // get recipe data
      requester.get('appdata', `recipes/${recipeId}`, 'kinvey')
        .then(function (recipeData) {
          recipeData.ingredients = recipeData.ingredients
            .split(/[^a-zA-Z]+/)
            .filter(e => e.length > 0);

          // display view
          ctx.loadPartials({
            header: '../templates/common/header.hbs',
            footer: '../templates/common/footer.hbs',
          }).then(function () {
            this.partial('../templates/recipes/details.hbs', {
              isLogged: Boolean(sessionStorage.getItem('authtoken')),
              names: sessionStorage.getItem('names'),
              isAuthor: (sessionStorage.getItem('userId') === recipeData._acl.creator),
              recipe: recipeData,
            }).then(function () {
              // add click event to 'Archive' button
              $('a[data-type="archive"]').click(function (ev) {
                helpFunctions.onRemoveClick(ev, ctx);
              });

              // add click event to 'Like' button
              $('a[data-type="like"]').click(function (ev) {
                helpFunctions.onLikeClick(ev, ctx);
              });
            })
          });
        })
        .catch(err => auth.showError(err.responseJSON.description));
    });


    // edit - get
    this.get('#/edit/:recipeId', function (ctx) {
      const recipeId = ctx.params.recipeId;
      // get recipe data
      requester.get('appdata', `recipes/${recipeId}`, 'kinvey')
        .then(function (recipeData) {
          //display view
          ctx.loadPartials({
            header: '../templates/common/header.hbs',
            footer: '../templates/common/footer.hbs',
          }).then(function () {
            this.partial('../templates/recipes/edit.hbs', {
              isLogged: Boolean(sessionStorage.getItem('authtoken')),
              names: sessionStorage.getItem('names'),
              recipe: recipeData,
            });
          });
        })
        .catch(err => auth.showError(err.responseJSON.description));
    });


    // edit - post
    this.post('#/edit/:recipeId', function (ctx) {
      const recipeId = ctx.params.recipeId;
      const newData = {
        meal: ctx.params.meal,
        ingredients: ctx.params.ingredients,
        prepMethod: ctx.params.prepMethod,
        description: ctx.params.description,
        foodImageURL: ctx.params.foodImageURL,
        category: ctx.params.category
      };

      // get old data
      requester.get('appdata', `recipes/${recipeId}`, 'kinvey')
        .then(function (oldData) {
          oldData.meal = newData.meal;
          oldData.ingredients = newData.ingredients;
          oldData.prepMethod = newData.prepMethod;
          oldData.description = newData.description;
          oldData.foodImageURL = newData.foodImageURL;
          oldData.category = newData.category;

          // post updated recipe to kinvey
          requester.update('appdata', `recipes/${recipeId}`, 'kinvey', JSON.parse(JSON.stringify(oldData)))
            .then(function () {
              auth.showInfo('Successfully updated.');
              setTimeout(function () {
                ctx.redirect('#/home');
              }, 1000);
            })
            .catch(err => auth.showError(err.responseJSON.description));
        })
        .catch(err => auth.showError(err.responseJSON.description));


    });







  });

  app.run('#/home');
});