let helpFunctions = (() => {
 
  // add 1 like
  function addLike(recipeId, ctx) {
    requester.get('appdata', `recipes/${recipeId}`, 'kinvey')
      .then(function (recipeData) {
        recipeData.likesCounter = Number(recipeData.likesCounter) + 1;
        requester.update('appdata', `recipes/${recipeId}`, 'kinvey', JSON.parse(JSON.stringify(recipeData)))
          .then(function () {
            auth.showInfo('You liked that recipe.');

            // reload the page
            setTimeout(function () {
              ctx.redirect('#/home');
            }, 1000);
          })
          .catch(err => auth.showError(err.responseJSON.description));
      })
      .catch(err => auth.showError(err.responseJSON.description));
  }


  // add 1 listen to song with _id=songId
  function addListen(songId, app) {
    requester.get('appdata', `songs/${songId}`, 'kinvey')
      .then(function (songData) {
        songData.listened = Number(songData.listened) + 1;
        requester.update('appdata', `songs/${songId}`, 'kinvey', JSON.parse(JSON.stringify(songData)))
          .then(function () {
            auth.showInfo(`You just listened ${songData.title}`);

            // reload the page
            app.refresh();
          })
          .catch(err => auth.showError(err.responseJSON.description));
      })
      .catch(err => auth.showError(err.responseJSON.description));

  }


  // delete recipe from kinvey
  function removeRecipe(recipeId, ctx) {
    requester.remove('appdata', `recipes/${recipeId}`, 'kinvey')
      .then(function () {
        auth.showInfo('Your recipe was archived.');
        // redirect
        setTimeout(function () {
          ctx.redirect('#/home');
        }, 1000);
      })
      .catch(err => auth.showError(err.responseJSON.description));
  }

  // event handler for 'Like' button click
  function onLikeClick(ev, ctx) {
    ev.preventDefault();
    ev.stopPropagation();
    let recipeId = ev.target.dataset.id;
    addLike(recipeId, ctx);
  }


  // event handler for 'Remove' button click
  function onRemoveClick(ev, ctx) {
    ev.preventDefault();
    ev.stopPropagation();
    let recipeId = ev.target.dataset.id;
    removeRecipe(recipeId, ctx);
  }

  return {
    addLike,
    removeRecipe,
    onLikeClick,
    onRemoveClick
  }
})();